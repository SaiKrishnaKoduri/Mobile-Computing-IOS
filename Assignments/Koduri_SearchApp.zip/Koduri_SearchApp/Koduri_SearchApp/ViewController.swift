//
//  ViewController.swift
//  Koduri_SearchApp
//
//  Created by Koduri,Sai Krishna on 3/19/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextfield: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var searchBtn: UIButton!
    
    @IBOutlet weak var prevBtn: UIButton!
    
    @IBOutlet weak var resetBtn: UIButton!
    
    @IBOutlet weak var nextBTN: UIButton!
    
    var imgarr = [["ducati","harley","suzuki","triumph","kawasaki"],["bmw","ford","audi","mercedes","tesla"],["rolex","omega","tag","citizen","seiko"]]
    
    var bikes_keywords = ["ducati","harley","suzuki","triumph","kawasaki"]
    var cars_keywords = ["bmw","ford","audi","mercedes","tesla"]
    var watches_keywords = ["rolex","omega","tag","citizen","seiko"]
    
    var topics = 0
    var imgNumber = 0
    
    var topics_array = [["Ducati is an Italian company that designs and manufactures motorcycles. Headquartered in Bologna, Italy, Ducati is owned by German automotive manufacturer Audi.","Harley-Davidson, Inc., H-D, or Harley, is an American motorcycle manufacturer founded in 1903 in Milwaukee, Wisconsin.","Suzuki Motor Corporation is a Japanese multinational corporation headquartered in Minami-ku, Hamamatsu. Suzuki manufactures automobiles, motorcycles, all-terrain vehicles (ATVs), outboard marine engines, wheelchairs and a variety of other small internal combustion engines.","Triumph Motorcycles Ltd is the largest British motorcycle manufacturer, established in 1983 by John Bloor after the original company Triumph Engineering went into receivership.","Kawasaki Heavy Industries Ltd. (KHI) is a Japanese public multinational corporation primarily known as a manufacturer of motorcycles, engines, heavy equipment, aerospace and defense equipment, rolling stock and ships."],["Bayerische Motoren Werke AG, commonly referred to as BMW, is a German multinational corporation which produces luxury vehicles and motorcycles.","Ford Motor Company is an American multinational automaker that has its main headquarters in Dearborn, Michigan, a suburb of Detroit.","Audi AG is a German automobile manufacturer that designs, engineers, produces, markets and distributes luxury vehicles.","Mercedes-Benz is both a German automotive marque and, from late 2019 onwards, a subsidiary (Mercedes-Benz AG) of Daimler AG.","Tesla, Inc. is an American electric vehicle and clean energy company based in Austin, Texas."],["Rolex SA is a Swiss luxury watch manufacturer based in Geneva, Switzerland. Originally founded as Wilsdorf and Davis by Hans Wilsdorf and Alfred Davis in London, England in 1905, the company registered Rolex as the brand name of its watches in 1908.","Omega SA is a Swiss luxury watchmaker based in Biel/Bienne, Switzerland. Founded by Louis Brandt in La Chaux-de-Fonds in 1848, the company formally operated as the La Generale Watch Co. until incorporating the name Omega in 1903, becoming Louis Brandt et Frère - Omega Watch & Co..","TAG Heuer S.A. is a Swiss luxury watchmaker that designs, manufactures and markets watches and fashion accessories, as well as eyewear and mobile phones manufactured under license by other companies and carrying the Tag Heuer brand name.","Citizen Watch Co., Ltd. is an electronics company primarily known for its watches, and is the core company of a Japanese global corporate group based in Tokyo, Japan.","Seiko Holdings Corporation (セイコーホールディングス株式会社, Seikō Hōrudingusu Kabushiki-gaisha), commonly known as Seiko, is a Japanese holding company that has subsidiaries which manufactures and sells watches, clocks, electronic devices, semiconductors, jewelries, and optical products."]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        topics = 0
        
        resultImage.image = UIImage(named: "welcome")
        
        topicInfoText.isHidden = true
        topicInfoText.text = ""
        
        searchBtn.isEnabled = false
        
        prevBtn.isHidden = true
        
        nextBTN.isHidden = true
        
        resetBtn.isHidden = true
    }
    
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        
        imgNumber = imgNumber - 1
        nextBTN.isEnabled = true
        switch topics {
        case 1 :
            resultImage.image = UIImage (named: imgarr [0][imgNumber])
            topicInfoText.text = topics_array[0][imgNumber]
        case 2 :
            resultImage.image = UIImage (named: imgarr [1][imgNumber])
            topicInfoText.text = topics_array[1][imgNumber]
        case 3 :
            resultImage.image = UIImage (named: imgarr [2][imgNumber])
            topicInfoText.text = topics_array[2][imgNumber]
        default :
            print("enter into default")
            
        }
        if (imgNumber == 0) {
            prevBtn.isEnabled = false
        } else {
            prevBtn.isEnabled = true
        }
        
    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        
        
        imgNumber = 0
        topicInfoText.isHidden = false
        if(bikes_keywords.contains (searchTextfield.text!)) {
            topics = 1
            nextBTN.isEnabled = true
            prevBtn.isEnabled = false
            
            prevBtn.isHidden = false
            nextBTN.isHidden = false
            resetBtn.isHidden = false
            resultImage.image = UIImage (named: imgarr[0][0])
            topicInfoText.text = topics_array[0][0]
        } else if (cars_keywords.contains(searchTextfield.text!)) {
            topics = 2
            nextBTN.isEnabled = true
            prevBtn.isEnabled = false
            
            prevBtn.isHidden = false
            nextBTN.isHidden = false
            
            resetBtn.isHidden = false
            
            
            resultImage.image = UIImage (named: imgarr [1][0])
            topicInfoText.text = topics_array[1][0]
            
        } else if (watches_keywords.contains (searchTextfield.text!)){
            topics = 3
            nextBTN.isEnabled = true
            prevBtn.isEnabled = false
            
            prevBtn.isHidden = false
            nextBTN.isHidden = false
            resetBtn.isHidden = false
            resultImage.image = UIImage (named: imgarr [2][0])
            topicInfoText.text = topics_array[2][0]
            
            
        } else {
            resultImage.image = UIImage (named: "robo")
            prevBtn.isHidden = true
            nextBTN.isHidden = true
            resetBtn.isHidden = true
        }
        
    }
    
    
    @IBAction func showNextImagesBtn(_ sender: UIButton) {
        
        imgNumber = imgNumber + 1
        prevBtn.isEnabled = true
        nextBTN.isEnabled = true
        switch topics {
        case 1:
            resultImage.image = UIImage (named: imgarr [0][imgNumber])
            topicInfoText.text = topics_array[0][imgNumber]
        case 2:
            resultImage.image = UIImage (named: imgarr [1][imgNumber])
            topicInfoText.text = topics_array[1][imgNumber]
        case 3:
            resultImage.image = UIImage (named: imgarr[2][imgNumber])
            topicInfoText.text = topics_array[2][imgNumber]
        default:
            print ("")
        }
        if (imgNumber == imgarr[0].count - 1) {
            nextBTN.isEnabled = false
        } else {
            nextBTN.isEnabled = true
        }
        
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        
        searchTextfield.text = ""
        imgNumber = 0
        searchBtn.isEnabled = false
        resultImage.image = UIImage(named: "welcome")
        
        topicInfoText.text = ""
        prevBtn.isHidden = true
        nextBTN.isHidden = true
        resetBtn.isHidden = true
        topics = 0
        topicInfoText.isHidden = true
        
    }
    
    
    @IBAction func editText(_ sender: UITextField) {
        
        if searchTextfield.text!.isEmpty{
            searchBtn.isEnabled = false
        } else {
            searchBtn.isEnabled = true
        }
    }
    
    
    
}


