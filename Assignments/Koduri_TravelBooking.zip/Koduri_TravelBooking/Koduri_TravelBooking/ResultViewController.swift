//
//  ResultViewController.swift
//  Koduri_TravelBooking
//
//  Created by Sai Krishna Koduri on 4/2/24.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    @IBOutlet weak var resultOL: UILabel!
    

    @IBOutlet weak var travellerNameOL: UILabel!
    
    @IBOutlet weak var noOfTravellersOL: UILabel!
    
    @IBOutlet weak var cabinTypeOL: UILabel!
    
    
    @IBOutlet weak var totalCostOL: UILabel!
    
    
    
        var name = ""
        var number = 0
        var type = ""
        var result = ""
        var price = 0.0
        var totalprice: Double = 0.0
        var image = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(type == "Economy" || type == "Luxury"){
            imageOL.image = UIImage(named: image)
            resultOL.text = "Hello \(name), your Booking is Confirmed,"
            travellerNameOL.text = "Name: \(name)"
            noOfTravellersOL.text = "Number of Travllers: \(number)"
            cabinTypeOL.text = "Cabin Class: \(type)"
            totalCostOL.text = "Total: \(totalprice)$"
        }
        else{
            imageOL.image = UIImage(named: image)
            resultOL.text = "There is no selected class. Please choose a valid class."
            travellerNameOL.isHidden = true
            noOfTravellersOL.isHidden = true
            cabinTypeOL.isHidden = true
            totalCostOL.isHidden = true
        }
        

        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
