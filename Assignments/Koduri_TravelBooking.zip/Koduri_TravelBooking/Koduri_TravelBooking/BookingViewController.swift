//
//  ViewController.swift
//  Koduri_TravelBooking
//
//  Created by Sai Krishna Koduri on 4/2/24.
//

import UIKit

class BookingViewController: UIViewController {
    
    @IBOutlet weak var travellerNameOL: UITextField!
    
    @IBOutlet weak var noOfTravellerOL: UITextField!
    
    
    @IBOutlet weak var cabinTypeOL: UITextField!
    
    var name = ""
    var number = 0
    var type = ""
    var result = ""
    var price = 0.0
    var totalprice: Double = 0.0
    var image = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func bookNowButton(_ sender: Any) {
        number = Int(noOfTravellerOL.text!)!
        name = travellerNameOL.text!
        type = cabinTypeOL.text!
        
        if(type == "Economy"){
            price = 125
            totalprice = (price * Double(number))
            image = "economy"
        }
        else if(type == "Luxury"){
            price = 200
            totalprice = (price * Double(number))
            image = "luxury"
        }
        else{
            price = 0
            totalprice = price*Double(number)
            image = "noBus"
        }
        
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(segue.identifier == "resultSegue"){
            let destination = segue.destination as! ResultViewController
            
            //assigning viewController variables to viewController variables
            //left side are from Resuult viewController
            destination.name = name
            destination.number = number
            destination.type = type
            destination.result = result
            destination.price = price
            destination.totalprice = totalprice
            destination.image = image
        }
    }}


