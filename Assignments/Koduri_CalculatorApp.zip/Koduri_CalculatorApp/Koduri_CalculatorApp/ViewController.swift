//
//  ViewController.swift
//  Koduri_CalculatorApp
//
//  Created by Sai Krishna Koduri on 2/8/24.
//


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultOutlet: UILabel!
    var inp1:String = " "
    var inp2:String = " "
    var res:Character = " ";
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btn_AC(_ sender: Any) {
        resultOutlet.text=""
        inp1 = " "
        inp2 = " "
        res = " "
    }
    
    @IBAction func btn_C(_ sender: Any) {
        if(inp2 != " "){
            inp2=String(inp2[inp2.startIndex..<inp2.index(inp2.endIndex,offsetBy: -1)])
            
            resultOutlet.text=inp2
            
        }
        
        else if(inp1 != " "){
            inp1=String(inp1[inp1.startIndex..<inp1.index(inp1.endIndex,offsetBy: -1)])
            resultOutlet.text=inp1
            
        }
    }
    
    @IBAction func btn_Negation(_ sender: Any) {
        if(inp2 != " "){
            if(inp2.contains(".")){
                inp2 = "\(-Double(inp2)!)"
                resultOutlet.text=inp2
            }
            else{
                inp2 = "\(-Int(inp2)!)"
                resultOutlet.text=inp2
            }
            
        }
        else if(inp1 != " ") {
            if(inp1.contains(".")){
                inp1 = "\(-Double(inp1)!)"
                resultOutlet.text=inp1
            }
            else{
                inp1 = "\(-Int(inp1)!)"
                resultOutlet.text=inp1
            }
        }
    }
    
    @IBAction func btn_Div(_ sender: Any) {
        res="/"
        
    }
    
    @IBAction func btn_Seven(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="7"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"7"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "7"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"7"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Eight(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="8"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"8"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "8"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"8"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Nine(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="9"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"9"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "9"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"9"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Mul(_ sender: Any) {
        res="*"
    }
    
    @IBAction func btn_Four(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="4"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"4"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "4"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"4"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Five(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="5"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"5"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "5"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"5"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Six(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="6"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"6"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "6"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"6"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Sub(_ sender: Any) {
        res="-"
        
    }
    
    @IBAction func btn_One(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="1"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"1"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "1"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"1"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Two(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="2"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"2"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "2"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"2"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Three(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="3"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"3"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "3"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"3"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Add(_ sender: Any) {
        res="+"
        
    }
    
    @IBAction func btn_Zero(_ sender: Any) {
        if (inp1 == " " && res == " " ){
            inp1="0"
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " " ){
            inp1=inp1+"0"
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2 = "0"
            resultOutlet.text="\(inp2)"
        }
        else if(inp2 != " "){
            inp2=inp2+"0"
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Dec(_ sender: Any) {
        if(inp1 == " " && res == " "){
            inp1="0."
            resultOutlet.text="\(inp1)"
        }else if(inp1 != " " && res == " "){
            inp1=inp1+"."
            resultOutlet.text="\(inp1)"
        }
        else if(inp2 == " " && res != " "){
            inp2="0."
            resultOutlet.text="\(inp2)"
        }else if(inp2 != " "){
            inp2=inp2+"."
            resultOutlet.text="\(inp2)"
        }
    }
    
    @IBAction func btn_Mod(_ sender: Any) {
        res="%"
        
    }
    
    @IBAction func btn_IsEqualTo(_ sender: Any) {
        switch res{
        case "+" :
            if(inp1.contains(".")){
                let val = "\(Double(inp1)! + Double(inp2)!)"
                let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                if(dec != "0"){
                    resultOutlet.text = val
                }
                else{
                    resultOutlet.text = "\(Int(Double(inp1)! + Double(inp2)!))"
                }
                
            }
            else {
                resultOutlet.text = "\(Int(inp1)! + Int(inp2)!)"
            }
            
            
        case "-" :
            
            if(inp1.contains(".")){
                resultOutlet.text = "\(Double(inp1)! - Double(inp2)!)"
            }
            else {
                resultOutlet.text = "\(Int(inp1)! - Int(inp2)!)"
            }
            
        case "*" :
            if(inp1.contains(".")){
                resultOutlet.text = "\(Double(inp1)! * Double(inp2)!)"
            }
            else {
                resultOutlet.text = "\(Int(inp1)! * Int(inp2)!)"
            }
            
        case "/" :
            if(inp1.contains(".")){
                resultOutlet.text = "\(Double(inp1)! / Double(inp2)!)"
            }
            else {
                if(inp2 == "0"){
                    resultOutlet.text = "Not a number"
                }
                else{
                    let calc = "\(Double(inp1)! / Double(inp2)!)"
                    let calcindex=calc.firstIndex(of: ".")!.utf16Offset(in: calc)
                    let last = calc[calc.index(calc.startIndex,offsetBy: calcindex+1)]
                    if(last != "0"){
                        resultOutlet.text = "\(round(Double(calc)!*100000)/100000)"
                    }
                    else{
                        resultOutlet.text = "\(Int(inp1)! / Int(inp2)!)"
                    }
                }
                
            }
            
        case "%" :
            
            if(inp1.contains(".")){
                var val = Double(inp1)!.truncatingRemainder(dividingBy: Double(inp2)!)
                resultOutlet.text = "\(round(val*10)/10)"
            }
            else {
                resultOutlet.text = "\(Int(inp1)! % Int(inp2)!)"
            }
            
            
        default:
            print("enter proper sign")
            
            
        }
    }
    
}



