//
//  ViewController.swift
//  Koduri_Assignment02
//
//  Created by Sai Krishna Koduri on 1/30/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameOutlet: UITextField!
    @IBOutlet weak var billAmountOutlet: UITextField!
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    @IBOutlet weak var dateOutlet: UIDatePicker!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var billAmountLabel: UILabel!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var totalAmountLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func SubmitBtn(_ sender: UIButton) {
        var dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm:ss"
        dateFormatter.timeZone = TimeZone(identifier: "America/Chicago")
        var name = nameOutlet.text!
        var bill = Double(billAmountOutlet.text!) ?? 0
        var tip = Double(tipPercentageOutlet.text!) ?? 0
        nameLabel.text = "Name: \(name)"
        billAmountLabel.text = "Bill Amount: $\(bill)"
        dateLabel.text = "\(dateFormatter.string(from: dateOutlet.date))"
        var tipAmount = (bill * tip) / 100
        var totalAmount = bill + tipAmount
        tipAmountLabel.text = "Tip Amount: $\(tipAmount)"
        totalAmountLabel.text = "Total Amount: $\(totalAmount)"
    }
    @IBAction func ResetBtn(_ sender: UIButton) {
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        
        dateLabel.text = ""
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""
    }
}

