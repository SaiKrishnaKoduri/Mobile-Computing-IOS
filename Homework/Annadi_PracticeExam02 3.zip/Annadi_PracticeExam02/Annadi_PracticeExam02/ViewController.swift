//
//  ViewController.swift
//  Annadi_PracticeExam02
//
//  Created by Chandana Annadi on 4/9/24.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var LoanTypeOL: UITextField!
    
    
    @IBOutlet weak var LoanAmountOL: UITextField!
    
    
    @IBOutlet weak var InterestRateOL: UITextField!
    
    
    @IBOutlet weak var TermOL: UITextField!
    
    @IBOutlet weak var calcOL: UIButton!
    
    @IBOutlet weak var resetOL: UIButton!
    
    
    var LoanType=""
    var LoanAmount=""
    var InterestRate=""
    var Term=""
    var MonthlyEMI=0.00
    var image=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
            
        calcOL.isEnabled = false
        resetOL.isEnabled = false
    }

    
    @IBAction func CalculateEMIBtn(_ sender: Any) {
        LoanType=LoanTypeOL.text!
        LoanAmount=LoanAmountOL.text!
        InterestRate=InterestRateOL.text!
        Term=TermOL.text!
        var totalmonths=(Int(Term)! * 12)
        var monthlyintrate=((Double(InterestRate)!/12))/100
        MonthlyEMI = Double(LoanAmount)! * (monthlyintrate * pow(1+monthlyintrate,Double(totalmonths)))/(pow(1+monthlyintrate,Double(totalmonths))-1)
        
        if LoanType=="Car"{
            image="Car"
            
        }
        else if LoanType=="Personal"{
            image="Personal"
        }
        else{
            image="Home"
        }
        
    }
    
    
    @IBAction func ResetBtn(_ sender: Any) {
        
        LoanTypeOL.text = ""
                LoanAmountOL.text = ""
                InterestRateOL.text = ""
                TermOL.text = ""
        
        calcOL.isEnabled = false
        resetOL.isEnabled = false
    }
    
    
    @IBAction func LoanTypes(_ sender: Any) {
        updateButton()
    }
    
    
    @IBAction func LoanAmounts(_ sender: Any) {
        updateButton()
    }
    
    
    @IBAction func InterestRates(_ sender: Any) {
        updateButton()
    }
    
    
    @IBAction func Terms(_ sender: Any) {
        updateButton()
    }
    
    
    
    func updateButton(){
        calcOL.isEnabled = (LoanTypeOL.text?.isEmpty == false) && (LoanAmountOL.text?.isEmpty == false) && (InterestRateOL.text?.isEmpty == false) && (TermOL.text?.isEmpty == false)
            resetOL.isEnabled = calcOL.isEnabled
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
                if(segue.identifier == "resultSegue")
                {
                    let destination = segue.destination as! ResultViewController
                    destination.LoanType=LoanType
                    destination.LoanAmount=LoanAmount
                    destination.InterestRate=InterestRate
                    destination.Term=Term
                    destination.MonthlyEMI=MonthlyEMI
                    destination.image=image
                }
        }

    
}

