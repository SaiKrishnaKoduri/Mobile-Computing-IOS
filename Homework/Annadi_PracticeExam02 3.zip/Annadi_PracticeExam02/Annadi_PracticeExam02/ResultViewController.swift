//
//  ResultViewController.swift
//  Annadi_PracticeExam02
//
//  Created by Chandana Annadi on 4/9/24.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var LoanTypeOL: UILabel!
    
    
    @IBOutlet weak var LoanAmountOL: UILabel!
    
    
    @IBOutlet weak var InterestRateOL: UILabel!
    
    
    @IBOutlet weak var MontlyEmiOL: UILabel!
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    var LoanType=""
    var LoanAmount=""
    var InterestRate=""
    var Term=""
    var MonthlyEMI=0.00
    var image=""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        LoanTypeOL.text="Loan Type: \(LoanType)"
        LoanAmountOL.text="Enterd Loan Amount: \(LoanAmount)"
        InterestRateOL.text="Enterd Interest Rate: \(InterestRate)"
        let monthlyemi = String(format: "%.2f",MonthlyEMI)
        MontlyEmiOL.text="Calculated Monthly EMI: \(monthlyemi)"
        imageViewOL.image=UIImage(named: image)
        
        var width = imageViewOL.frame.width
        
        width += 40
        
        var height = imageViewOL.frame.height
        
        height += 40
        
        var x = imageViewOL.frame.origin.x-20
        var y = imageViewOL.frame.origin.y-20
        
        
        
        var larger = CGRect(x: x, y: y, width: width, height: height)
        UIView.animate(withDuration: 1, delay: 0.5, usingSpringWithDamping: 1, initialSpringVelocity: 50, animations: {
            self.imageViewOL.frame = larger
        })
    }
    
   
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
