//
//  ViewController.swift
//  AnimeDisplayApp
//
//  Created by YourName on 2024-02-26.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var posterImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var releaseYearLabel: UILabel!
    
    @IBOutlet weak var episodeCountLabel: UILabel!
    
    @IBOutlet weak var previousButton: UIButton!
    
    
    @IBOutlet weak var nextButton: UIButton!
    
    let animes = [
        ["naruto.jpeg", "Naruto", "2002", "500 eps"],
        ["dbz.jpeg", "Dragon Ball Z", "1986", "153 eps"],
        ["onepiece.jpeg", "One Piece", "1999", "1100 eps"]
    ]
    
    var currentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Disable previous button initially
        previousButton.isEnabled = false
        // Display the first anime
        updateAnimeInfo(currentIndex)
    }
    
    @IBAction func previousButtonClicked(_ sender: Any) {
        // decrement the image number
        currentIndex -= 1
        updateAnimeInfo(currentIndex)
        // once you reach the begining of the array, disable previous button
        if(currentIndex == 0){
            previousButton.isEnabled = false
        }
        // next button enabled to true
        nextButton.isEnabled = true
    }

    
    @IBAction func nextButtonClicked(_ sender: Any) {
        // previous button should enabled
        previousButton.isEnabled = true
        // increment the image number
        currentIndex += 1
        updateAnimeInfo(currentIndex)
        // once the use reach end of the array, the next button should be disabled
        if(currentIndex == animes.count-1){
            nextButton.isEnabled = false
        }
    }
    
    func updateAnimeInfo(_ index: Int) {
        posterImageView.image = UIImage(named: animes[index][0])
        titleLabel.text = animes[index][1]
        releaseYearLabel.text = animes[index][2]
        episodeCountLabel.text = animes[index][3]
    }
}
