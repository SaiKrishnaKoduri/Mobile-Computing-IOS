//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Koduri,Sai Krishna on 3/28/24.
//

import UIKit

class Product{
    var productName:String?
    var productCategory:String?
    init(productName: String? = nil, productCategory: String? = nil) {
        self.productName = productName
        self.productCategory = productCategory
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return total no. of products
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        //populate a cell
        cell.textLabel?.text = products[indexPath.row].productName
        //return a cell
        return cell
    }
    
    
    @IBOutlet weak var tableViewOL: UITableView!
    
    var products = [Product]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewOL.delegate = self
        tableViewOL.dataSource = self
        
        // Do any additional setup after loading the view.
        let p1 = Product(productName: "IPhone",productCategory: "Mobile Phone")
        products.append(p1)
        let p2 = Product(productName: "OnePlus",productCategory: "Mobile Phone")
        products.append(p2)
        let p3 = Product(productName: "Nintendo Switch",productCategory: "Gaming Console")
        products.append(p3)
        let p4 = Product(productName: "Play Station",productCategory: "Gaming Console")
        products.append(p4)
        let p5 = Product(productName: "Vision Pro",productCategory: "Virtual Reality")
        products.append(p5)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(segue.identifier == "prodDescriptionSegue"){
            let destination = segue.destination as! DescriptionViewController
            destination.product = products[(tableViewOL.indexPathForSelectedRow?.row)!]
        }
        
    }


}

