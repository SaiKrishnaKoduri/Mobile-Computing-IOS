//
//  ViewController.swift
//  CoordinatesDemo1
//
//  Created by Sai Krishna Koduri on 2/29/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // Identify the minimum of x and y values of image view
        let minX = imageViewOL.frame.minX
        let minY = imageViewOL.frame.minY
        print("(\(minX),\(minY))")
        let maxX = imageViewOL.frame.maxX
        let maxY = imageViewOL.frame.maxY
        // // Identify the maximum values of x and y of image view
        print("(\(maxX),\(maxY))")
        // Identify the mid values of x and y of image view
        let midX = imageViewOL.frame.midX
        let midY = imageViewOL.frame.midY
        print("(\(midX),\(midY))")
        // Move the image view to the upper left corner of the view
        //imageViewOL.frame.origin.x=0
        //imageViewOL.frame.origin.y=0
        // Move the image view to the upper right corner of the view
        //imageViewOL.frame.origin.x=330
        //imageViewOL.frame.origin.y=0
        // Move the image view to the bottom right corner of the view
        //imageViewOL.frame.origin.x=330
        //imageViewOL.frame.origin.y=832
        // Move the image view to the bottom left corner of the view
        //imageViewOL.frame.origin.x=0
        //imageViewOL.frame.origin.y=832
        // Move the image view to the center of the view
        //imageViewOL.frame.origin.x=215
        //imageViewOL.frame.origin.y=466
        // Move the center of theimage view to the center of the view
        imageViewOL.frame.origin.x=165
        imageViewOL.frame.origin.y=416
        
        
        
        
    }


}

