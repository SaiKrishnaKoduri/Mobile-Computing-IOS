//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Koduri,Sai Krishna on 2/22/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageViewOL: UIImageView!
    @IBOutlet weak var courseNumOL: UILabel!
    @IBOutlet weak var courseTtlOL: UILabel!
    @IBOutlet weak var semOL: UILabel!
    @IBOutlet weak var previousOL: UIButton!
    @IBOutlet weak var nextOL: UIButton!
    
    let courses = [["img01.jpeg", "44555", "Network Security", "Fall"],["img02.jpeg", "44666", "IOS", "Spring"],["img03.jpeg", "44556", "Data Streaming", "Summer"]]
    
    var imgNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // previous button should be displayed
        previousOL.isEnabled = false
        // Display the first course details (Index 0)
        updateContents(imgNum)
    }
    
    @IBAction func prevBtnClicked(_ sender: Any) {
        // decrement the image number
        imgNum -= 1
        updateContents(imgNum)
        // once you reach the begining of the array, disable previous button
        if(imgNum == 0){
            previousOL.isEnabled = false
        }
        // next button enabled to true
        nextOL.isEnabled = true
    }
    
    @IBAction func nextBtnClicked(_ sender: Any) {
        // previous button should enabled
        previousOL.isEnabled = true
        // increment the image number
        imgNum += 1
        updateContents(imgNum)
        // once the use reach end of the array, the next button should be disabled
        if(imgNum == courses.count-1){
            nextOL.isEnabled = false
        }
        
    }
    // helper function to update the content
    func updateContents(_ imageNumber:Int){
        imageViewOL.image = UIImage(named: courses[imageNumber][0])
        courseTtlOL.text = courses[imageNumber][1]
        courseNumOL.text = courses[imageNumber][2]
        semOL.text = courses[imageNumber][3]
    }
    
}

