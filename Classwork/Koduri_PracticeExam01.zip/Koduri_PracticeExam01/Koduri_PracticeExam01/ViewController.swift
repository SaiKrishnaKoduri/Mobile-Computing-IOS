//
//  ViewController.swift
//  Koduri_PracticeExam01
//
//  Created by Koduri,Sai Krishna on 2/13/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var inputOL1: UITextField!
    @IBOutlet weak var inputOL2: UITextField!
    @IBOutlet weak var inputOL3: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    @IBOutlet weak var imageOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func calculateBMI(_ sender: Any) {
        var h = Double(inputOL1.text!) ?? 0
        var i = Double(inputOL2.text!) ?? 0
        var l = Double(inputOL3.text!) ?? 0
        var th = Double(h*12)+i
        var w = Double(703 * (l / (th * th)))
        var res = (w * 10).rounded() / 10
        //var res = String(format:"%.1f",w)
        if(res <= 18.5){
            outputOL.text = "Your Body Mass Index is \(res) \nThis is considered Underweight."
            imageOL.image = UIImage(named:"underWeight.jpeg")
        }
        else if(res>=18.6 && res<=24.9){
            outputOL.text = "Your Body Mass Index is \(res) \nThis is considered Normal."
            imageOL.image = UIImage(named:"normal.jpeg")
        }
        else if(res>=25 && res<=29.9){
            outputOL.text = "Your Body Mass Index is \(res) \nThis is considered Overweight."
            imageOL.image = UIImage(named:"overWeight.jpeg")
        }
        else{
            outputOL.text = "Your Body Mass Index is \(res) \nThis is considered Obesity."
            imageOL.image = UIImage(named:"obese.jpeg")
        }
    }
    

}

