//
//  MovieCollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Koduri,Sai Krishna on 4/2/24.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    func assignMovie(with movie:Movie){
        imageViewOL.image = movie.image
    }
    
}
