import UIKit

//Dictionaries

var capitals = ["Andhra Pradesh":"Amaravati","Telangana":"Hydrabad","Tamil Nadu":"Chennai","Karnataka":"Banglore","Kerala":"Thiruvananthapuram"]
print(capitals)
print(capitals.count)

var numbers = [1:"One",2:"Two",3:"Three"]
print(numbers)
numbers[6] = "Six"
numbers[4] = "Five"
print(numbers)

var courses = [44542:"Java",44560:"Database",44613:"Data Visualization"]
print("Before changing \(courses)")
courses[44542] = "Java Script"
print("After changing \(courses)")

print(courses[44542])

courses.removeValue(forKey: 44613)
print(courses)

for(key,values) in courses{
    print(key)
}

for(key,values) in courses{
    print(values)
}

for(key,values) in courses{
    print("\(key) : \(values)")
}

//Sets

var players : Set<String> = ["MS Dhoni", "Suresh Raina", "Ravichandran Ashwin", "Ravi Jadeja"]
print(players.count)
print(players)

print(players.contains("Steve Smith"))

players.insert("Rohit Sharma")
print(players)

players.remove("Ravichandran Ashwin")
print(players)

var primeNumbers : Set<Int> = [2,3,5,7,11]
var numbersList : Set<Int> = [1,2,5,9]

var unionSet : Set<Int> = primeNumbers.union(numbersList)
print(unionSet)

var intersectionSet : Set<Int> = primeNumbers.intersection(numbersList)
print(intersectionSet)

var subtractionSet : Set<Int> = primeNumbers.subtracting(numbersList)
print(subtractionSet)

var symmDiffSet : Set<Int> = primeNumbers.symmetricDifference(numbersList)
print(symmDiffSet)

print(primeNumbers.isSubset(of: numbersList))

//Arrays

var numberss:[Int] = [2,3,4]
print(numberss)

var emptyArray = [Int] ()
print(emptyArray)

var programmingLanguages = ["Swift", "Java", "Python"]
print(programmingLanguages[0])

var programmingLanguagess = ["Swift", "Java", "Python"]
programmingLanguagess[0] = "Java Script"
print(programmingLanguagess[0])

var names:[String] = ["Oliver", "Elijah", "James"]
print("Before appending \(names)")
names.append("Masthan")
print("After appending \(names)")

print("Before inserting \(names)")
names.insert("Benjamin", at: 2)
print("After inserting \(names)")

print(names.count)

names.sort()
print("After sorting \(names)")

names.reverse()
print("After reversing \(names)")

names.remove(at: 2)
print("After removing \(names)")

names.swapAt(1, 2)
print("After swapping \(names)")

var oddNumbers = [1,3,5,7]
var evenNumbers = [2,4,6,8]
oddNumbers.append(contentsOf: evenNumbers)
print("After combining \(oddNumbers)")
