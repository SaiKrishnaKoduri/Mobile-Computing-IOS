import UIKit

print("Hi",10,12.25)

var programmingLanguage = "Swift"
print("My favorite programming language is \(programmingLanguage)")

var age = 23
print("You are \(age) years old and in another \(age) years you will be \(age*2) years🥳")

print("""
Hello
World!
""")

print("Hello All,\rWelcome to swift programming")

let welcomeMessage : String = "Hello!"
print(welcomeMessage, "All")
