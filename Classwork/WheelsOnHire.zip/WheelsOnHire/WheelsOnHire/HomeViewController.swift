//
//  ViewController.swift
//  WheelsOnHire
//
//  Created by Koduri,Sai Krishna on 4/4/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userNameOL: UITextField!
    
    @IBOutlet weak var passwordOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func sigInClickeBtn(_ sender: Any) {
        
    }
    

}

