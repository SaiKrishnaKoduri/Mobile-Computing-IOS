//
//  ViewController.swift
//  WordGuessApp
//
//  Created by Sai Krishna Koduri on 2/27/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var displayLabelOL: UILabel!
    @IBOutlet weak var hintLabelOL: UILabel!
    @IBOutlet weak var textOL: UITextField!
    @IBOutlet weak var checkOL: UIButton!
    @IBOutlet weak var statusLabelOL: UILabel!
    @IBOutlet weak var playAgainOL: UIButton!
    
    var words = [["SWIFT", "Programming Language"],
                 ["DOG", "Animal"],
                 ["CYCLE", "Two wheeler"],
                 ["MACBOOK", "Apple device"]]
    var count = 0;
    var word = ""
    var lettersGuessed = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Check button should be disabled
        checkOL.isEnabled = false
        word = words[count][0]
        displayLabelOL.text = ""
        //Populate the number of underscores in the display label, the number of underscores is equal to number of characters in the word
        updateUnderscores()
        //Get first hint from the array
        hintLabelOL.text = "Hint: "+words[count][1]
        //clear the status label initially
        statusLabelOL.text = ""
    }
    
    @IBAction func textChange(_ sender: Any) {
        //Read the data from the text field
        var textEnterd = textOL.text!;
        //Consider only the last character by calling textEntered.last and trimming the white spaces.
        textEnterd = String(textEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
        textOL.text = textEnterd
        
        //Check whether the entered text is empty or not to enable check button.
        if textEnterd.isEmpty{
            checkOL.isEnabled = false
        }
        else{
            checkOL.isEnabled = true
        }
        
    }
    
    @IBAction func checkButtonClicked(_ sender: Any) {
        //Get the text from the text field
        var letter = textOL.text!
        //Replace the guessed letter if the letter is part of the word.
        lettersGuessed = lettersGuessed + letter
        var revealedWord = ""
        for l in word{
            if lettersGuessed.contains(l){
                revealedWord += "\(l)"
            }
            else{
                revealedWord += "_ "
            }
        }
        //Assigning the word to displaylabel after a guess
        displayLabelOL.text = revealedWord
        textOL.text = ""
        //If the word is guessed correctly, we are enabling play again button and disabling the check button.
        if displayLabelOL.text!.contains("_") == false{
            playAgainOL.isHidden = false;
            checkOL.isEnabled = false;
        }
        checkOL.isEnabled = false
    }
    
    @IBAction func playAgainButtonClicked(_ sender: Any) {
        //Reset the button to disable initially.
        playAgainOL.isHidden = true
        //clear the label
        lettersGuessed = ""
        count += 1
        //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
        if count == words.count{
            statusLabelOL.text = "Congruations! You are done with the game!"
            //clearing the labels.
            displayLabelOL.text = ""
            hintLabelOL.text = ""
        }
        else{
            //fetch the next word from the array
            word = words[count][0]
            //fetch the hint related to the word
            hintLabelOL.text = "Hint: "
            hintLabelOL.text! += words[count][1]
            //Enabling the check button.
            checkOL.isEnabled = true
            
            displayLabelOL.text = ""
            updateUnderscores()
        }
    }
    
    func updateUnderscores(){
        for letter in word{
            displayLabelOL.text! += "_ "
        }
    }
}

