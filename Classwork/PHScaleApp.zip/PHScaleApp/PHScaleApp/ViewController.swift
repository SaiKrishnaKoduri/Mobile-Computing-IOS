//
//  ViewController.swift
//  PHScaleApp
//
//  Created by Koduri,Sai Krishna on 1/30/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var inputOL: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    @IBOutlet weak var imageOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func BtnClicked(_ sender: Any) {
        //Read the input PH value
        var ph = Int(inputOL.text!) ?? 0
        if(ph<7){
            outputOL.text = "It is Acid! ☢️"
            imageOL.image = UIImage(named:"vinegar.jpeg")
        }
        else if(ph==7){
            outputOL.text = "It is nuetral! 💧"
            imageOL.image = UIImage(named:"water.jpeg")
        }
        else{
            outputOL.text = "It is base! 🧼"
            imageOL.image = UIImage(named:"soap.jpeg")
        }
    }
    
}

