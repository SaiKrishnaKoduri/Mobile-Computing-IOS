//
//  ViewController.swift
//  WeatherAppMultipleViewController
//
//  Created by Koduri,Sai Krishna on 3/21/24.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var temperatureOL: UITextField!
    var result = ""
    var image = ""
    var temperature:Double = 0.0
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func checkWeatherButton(_ sender: Any) {
        //Read Temperature value andassign it to a variable
        temperature = Double(temperatureOL.text!)!
        //Check weathe (Hot/Cold)
        if(temperature<60.0){
            result = "It is cold🥶"
            image = "cold"
        }
        else{
            result = "It is hot🥵"
            image = "hot"
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //Know the identifier
        let transition = segue.identifier
        //Set the destination
        if(transition == "WeatherResultSegue"){
            let destination = segue.destination as! ResultViewController
            //Assign values to the destination variables
            destination.image = image
            destination.result = result
            destination.temperature = temperature
        }
        
    }
    
}

