//
//  ViewController.swift
//  WeatherApp
//
//  Created by Koduri,Sai Krishna on 1/30/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    @IBOutlet weak var imageOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func BtnClicked(_ sender: Any) {
        //Read input temperature
        var temp = Int(inputOL.text!) ?? 0
        if(temp >= 60){
            outputOL.text = "It is hot! 🥵"
            UIView.animate(withDuration: 1, delay: 0.5, animations: {
                self.imageOL.alpha = 0
                self.imageOL.alpha = 1
                self.imageOL.image = UIImage(named: "hot.jpeg")
            })
            
        }
        else{
            outputOL.text = "It is cold! 🥶"
            UIView.animate(withDuration: 1.5, delay: 1, animations: {
                self.imageOL.alpha = 0
                self.imageOL.alpha = 1
                self.imageOL.image = UIImage(named: "cold.jpeg")
            })
        }
            
    }
    
}

