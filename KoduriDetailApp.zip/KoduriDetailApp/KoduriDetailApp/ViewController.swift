//
//  ViewController.swift
//  KoduriDetailApp
//
//  Created by Koduri,Sai Krishna on 1/23/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL1: UITextField!
    @IBOutlet weak var inputOL2: UITextField!
    @IBOutlet weak var inputOL3: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitBtnClicked(_ sender: Any) {
        //Read the entered name, age and group
        var ip1 = inputOL1.text!
        var ip2 = inputOL2.text!
        var ip3 = inputOL3.text!
        //Assign it to the display or output label
        //String interpolate with appropriate messages
        outputOL.text = "Hi my name is \(ip1)\nMy age is \(ip2)\nMy group is \(ip3)"
    }
    
}

