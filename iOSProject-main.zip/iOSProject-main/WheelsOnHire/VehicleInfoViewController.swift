import UIKit

class VehicleInfoViewController: UIViewController {
    
    var name = ""
    var licenseNumber = ""
    var selectedCar: Car?
    var selectedBike: Bike?

    @IBOutlet weak var carImageView: UIImageView!
    @IBOutlet weak var carNameLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var licenseTextField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!

    override func viewDidLoad() {
        super.viewDidLoad()
        print(selectedCar)
        print(selectedBike)
        
        // Set car image and name
        if let car = selectedCar {
            carImageView.image = UIImage(named: car.images.first ?? "")
            carNameLabel.text = "\(car.make) \(car.model)"
        } else if let bike = selectedBike {
            // Handle bike selection (if needed)
            carImageView.image = UIImage(named: bike.images.first ?? "")
               carNameLabel.text = "\(bike.make) \(bike.model)"
        }
    }
    
    @IBAction func continueButtonTapped(_ sender: UIButton) {
        guard let name = nameTextField.text, !name.isEmpty else {
            showAlert(message: "Please enter your name.")
            return
        }
        
        guard let licenseNumber = licenseTextField.text, !licenseNumber.isEmpty else {
            showAlert(message: "Please enter your driver's license number.")
            return
        }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func days(from start: Date, to end: Date) -> Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.day], from: start, to: end)
        return components.day ?? 0
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "successSegue" {
            if let bookingDetailsVC = segue.destination as? ReceiptViewController {
                if let selectedCar = selectedCar {
                    // Handle car selection
                    let numberOfDays = days(from: Date(), to: datePicker.date)
                    guard numberOfDays > 0 else {
                        showAlert(message: "Please select valid rental period.")
                        return
                    }
                    let cost = Double(numberOfDays) * selectedCar.pricePerDay
                    
                    // Generate random receipt number
                    let receiptNumber = "REC\(Int.random(in: 100000..<1000000))"
                    
                    // Pass data to ReceiptViewController for cars
                    bookingDetailsVC.receiptNumber = receiptNumber
                    bookingDetailsVC.carName = "\(selectedCar.make) \(selectedCar.model)"
                    bookingDetailsVC.name = name
                    bookingDetailsVC.licenseNumber = licenseNumber
                    bookingDetailsVC.numberOfDays = numberOfDays
                    bookingDetailsVC.cost = cost
                } else if let selectedBike = selectedBike {
                    let numberOfDays = days(from: Date(), to: datePicker.date)
                    guard numberOfDays > 0 else {
                        showAlert(message: "Please select valid rental period.")
                        return
                    }
                    let cost = Double(numberOfDays) * selectedBike.pricePerDay
                    
                    // Generate random receipt number
                    let receiptNumber = "REC\(Int.random(in: 100000..<1000000))"
                    
                    // Pass data to ReceiptViewController for bikes
                    bookingDetailsVC.receiptNumber = receiptNumber
                    bookingDetailsVC.carName = "\(selectedBike.make) \(selectedBike.model)"
                    bookingDetailsVC.name = name
                    bookingDetailsVC.licenseNumber = licenseNumber
                    bookingDetailsVC.numberOfDays = numberOfDays
                    bookingDetailsVC.cost = cost
                }

            }
        }
    }
}
