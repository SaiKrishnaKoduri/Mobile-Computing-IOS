//
//  VehicleListViewController.swift
//  WheelsOnHire
//
//  Created by Varun Rachakatla on 11/04/24.
//

import UIKit

class VehicleListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if selected == "Car"{
            return cars.count
        }
        else if selected == "Bike"{
            return bikes.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let pull = vehicleListTableView.dequeueReusableCell(withIdentifier: "rentalTypeCell", for: indexPath)
        if selected == "Car"{
            let cell = vehicleListTableView.dequeueReusableCell(withIdentifier: "rentalTypeCell", for: indexPath)
            cell.textLabel!.text = "\(cars[indexPath.row].make)(\(cars[indexPath.row].model))"
            
            return cell
        }
        else if selected == "Bike"{
            let cell = vehicleListTableView.dequeueReusableCell(withIdentifier: "rentalTypeCell", for: indexPath)
            cell.textLabel!.text = "\(bikes[indexPath.row].make)(\(bikes[indexPath.row].model))"
            
            return cell
        }
        return pull
    }
    
    
    @IBOutlet weak var vehicleListTableView: UITableView!
    
    var selected = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        vehicleListTableView.dataSource = self
        vehicleListTableView.delegate = self
        // Do any additional setup after loading the view.
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if selected == "Car" {
            if indexPath.row < cars.count {
                let selectedCar = cars[indexPath.row]
                // Access the selected car directly
                performSegue(withIdentifier: "collectionSegue", sender: selectedCar)
            }
        } else {
            if indexPath.row < bikes.count {
                let selectedBike = bikes[indexPath.row] // Access the selected bike directly
                performSegue(withIdentifier: "collectionSegue", sender: selectedBike)
            }
        }
    }





    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "collectionSegue" {
            if let vehicleDetailVC = segue.destination as? VehicleCollecViewController {
                if let selectedVehicle = sender as? Car {
                    // Pass the selected vehicle as an array to the destination view controller

                    vehicleDetailVC.vehiclesSelectedCar = selectedVehicle
                }
                else if let selectedVehicle = sender as? Bike {
                                // Pass the selected vehicle (Bike) to the destination view controller
                                vehicleDetailVC.vehiclesSelectedBike = selectedVehicle
                            }
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
