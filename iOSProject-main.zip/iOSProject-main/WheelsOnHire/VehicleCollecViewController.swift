//
//  VehicleCollecViewController.swift
//  WheelsOnHire
//
//  Created by Varun Rachakatla on 11/04/24.
//

import UIKit

class VehicleCollecViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var vehicleDisplayCollection: UICollectionView!
    @IBOutlet weak var NameOL: UILabel!
    @IBOutlet weak var displayOL: UITextView!
    
    var vehiclesSelectedCar: Car?
    var vehiclesSelectedBike: Bike?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the delegate and data source for the collection view
        vehicleDisplayCollection.delegate = self
        vehicleDisplayCollection.dataSource = self
    }
    
    // MARK: - UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let selectedCar = vehiclesSelectedCar {
            return selectedCar.images.count
        } else if let selectedBike = vehiclesSelectedBike {
            return selectedBike.images.count
        } else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = vehicleDisplayCollection.dequeueReusableCell(withReuseIdentifier: "carImagesCell", for: indexPath) as! VehicleListCellCollectionViewCell
        
        if let selectedCar = vehiclesSelectedCar {
            cell.assignItem(with: selectedCar.images, at: indexPath)
        } else if let selectedBike = vehiclesSelectedBike {
            // Assuming the Bike model has similar image properties
            cell.assignItem(with: selectedBike.images, at: indexPath)
        }
        
        return cell
    }
    
    // MARK: - UICollectionViewDelegate
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let selectedCar = vehiclesSelectedCar {
            // Update labels with selected car data
            NameOL.text = "\(selectedCar.make) - \(selectedCar.model) (\(selectedCar.year))"
            displayOL.text = """
                Description: \(selectedCar.description)
                Fuel Type: \(selectedCar.fuelType)
                Transmission Type: \(selectedCar.transmissionType)
                Passenger Capacity: \(selectedCar.passengerCapacity)
                """
            // Perform any additional actions specific to cars
        } else if let selectedBike = vehiclesSelectedBike {
            // Update labels with selected bike data
            NameOL.text = "\(selectedBike.make) - \(selectedBike.model) (\(selectedBike.year))"
            displayOL.text = """
                Description: \(selectedBike.description)
                Fuel Type: \(selectedBike.fuelType)
                Engine Capacity: \(selectedBike.engineCapacity)
                """
            // Perform any additional actions specific to bikes
        }
    }
    
    @IBAction func continueBtnClicked(_ sender: Any) {
        if let selectedCar = vehiclesSelectedCar {
                // If it's a car, perform segue and pass the selected car
                performSegue(withIdentifier: "infoSegue", sender: selectedCar)
            } else if let selectedBike = vehiclesSelectedBike {
                // If it's a bike, perform segue and pass the selected bike
                performSegue(withIdentifier: "infoSegue", sender: selectedBike)
            } else {
                // Handle the case where neither car nor bike is selected
                print("Neither car nor bike is selected.")
            }
    }
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "infoSegue" {
            if let vehicleDetailVC = segue.destination as? VehicleInfoViewController {
                if let selectedVehicle = sender as? Car {
                    // Pass the selected vehicle (Car) to the destination view controller
                    vehicleDetailVC.selectedCar = selectedVehicle
                } else if let selectedVehicle = sender as? Bike {
                    // Pass the selected vehicle (Bike) to the destination view controller
                    vehicleDetailVC.selectedBike = selectedVehicle
                }
            }
        }
    }

}
