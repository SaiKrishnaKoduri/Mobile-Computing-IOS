//
//  ViewController.swift
//  WheelsOnHire
//
//  Created by Koduri,Sai Krishna on 4/4/24.
//

import UIKit
import Firebase
class HomeViewController: UIViewController {

    @IBOutlet weak var userNameOL: UITextField!
    
    @IBOutlet weak var passwordOL: UITextField!
    @IBOutlet weak var loginButton: UIButton!
        @IBOutlet weak var contentView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        passwordOL.isSecureTextEntry = true
        contentView.alpha = 0
    }
    override func viewDidAppear(_ animated: Bool) {
           super.viewDidAppear(animated)
           animateLoginView()
       }
       
       private func animateLoginView() {
           UIView.animate(withDuration: 1.0, delay: 0.5, options: .curveEaseInOut, animations: {
               self.contentView.alpha = 1 // Fade in the content
               self.userNameOL.transform = CGAffineTransform(translationX: 0, y: -20) // Move up the username field
               self.passwordOL.transform = CGAffineTransform(translationX: 0, y: -20) // Move up the password field
               self.loginButton.transform = CGAffineTransform(translationX: 0, y: 20) // Move down the login button
           }, completion: nil)
           
           // Add animation to the login button
           let animation = CABasicAnimation(keyPath: "transform.scale")
           animation.duration = 0.5
           animation.fromValue = 0.0
           animation.toValue = 1.0
           animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
           loginButton.layer.add(animation, forKey: "scaleAnimation")
       }
    @IBAction func sigInClickeBtn(_ sender: Any) {
        guard let email = userNameOL.text else{ return }
        guard let password = passwordOL.text else{ return }
        
        Auth.auth().signIn(withEmail: email, password: password) { firebaseResult, error in
            if let e = error {
                            // Handle sign-in failure
                            print("Sign-in failed:", e.localizedDescription)
                            // You can show an alert to the user indicating the failure
                            let alert = UIAlertController(title: "Error", message: e.localizedDescription, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
            else{
                //Go to
                self.performSegue(withIdentifier:"goToNext", sender: self)
            }
        }
    }
    

}

