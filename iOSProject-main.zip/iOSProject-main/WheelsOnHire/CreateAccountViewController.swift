//
//  CreateAccountViewController.swift
//  WheelsOnHire
//
//  Created by Koduri,Sai Krishna on 4/4/24.
//

import UIKit
import Firebase
class CreateAccountViewController: UIViewController {

    @IBOutlet weak var emailOL: UITextField!
    @IBOutlet weak var passwordOL: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        passwordOL.isSecureTextEntry = true
    }
    
    
    @IBAction func signUpBtnClicked(_ sender: UIButton) {
        guard let email = emailOL.text else{ return }
        guard let password = passwordOL.text else{ return }
        
        Auth.auth().createUser(withEmail: email, password: password) { firebaseResult, error in
            if let e = error {
                            // Handle sign-in failure
                            print("Sign-in failed:", e.localizedDescription)
                            // You can show an alert to the user indicating the failure
                            let alert = UIAlertController(title: "Error", message: e.localizedDescription, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
            else{
                // Sign-up successful, dismiss current view controller
                self.dismiss(animated: true) {
                    // Optionally, navigate to the sign-in page
                    // For example, you can present it modally
                    let signInVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                    self.present(signInVC, animated: true, completion: nil)
                }
            }
        }
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
