//
//  VehicleCollectionViewCell.swift
//  WheelsOnHire
//
//  Created by Varun Rachakatla on 11/04/24.
//

import UIKit

class VehicleCollectionViewCell: UICollectionViewCell {
    
}
