//
//  vehicleInfo.swift
//  WheelsOnHire
//
//  Created by Sai Krishna Koduri on 4/22/24.
//

import Foundation
import UIKit


import UIKit

struct Vehicle {
    let title: String
    let description: String
    let image: UIImage?
}

// Example usage:
let car = Vehicle(title: "Car", description: "A motor vehicle with four wheels, usually designed to carry a small number of passengers.", image: UIImage(named: "carImage"))
let bike = Vehicle(title: "Bike", description: "A two-wheeled vehicle that is powered by pedals and usually has a lightweight frame.", image: UIImage(named: "bikeImage"))


let vehicles = [car,bike]
