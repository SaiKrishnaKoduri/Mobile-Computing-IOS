//
//  Bike.swift
//  WheelsOnHire
//
//  Created by Sai Krishna Koduri on 4/22/24.
//

import Foundation
import UIKit

struct Bike {
    let make: String
    let model: String
    let year: Int
    let pricePerDay: Double
    let engineCapacity: Int
    let images: [String]
    let fuelType: String
    let description: String
}

let bikes: [Bike] = [
    Bike(make: "Honda", model: "CBR500R", year: 2021, pricePerDay: 40.0, engineCapacity: 500, images: ["honda_cbr500r_1.jpg", "honda_cbr500r_2.jpg", "honda_cbr500r_3.jpg"], fuelType: "Gasoline", description: "A sporty and agile motorcycle with a powerful engine."),
    Bike(make: "Kawasaki", model: "Ninja 650", year: 2020, pricePerDay: 45.0, engineCapacity: 650, images: ["kawasaki_ninja_650_1.jpg", "kawasaki_ninja_650_2.jpg", "kawasaki_ninja_650_3.jpg"], fuelType: "Gasoline", description: "A versatile sportbike with comfortable ergonomics and impressive performance."),
    Bike(make: "Yamaha", model: "YZF-R6", year: 2019, pricePerDay: 50.0, engineCapacity: 600, images: ["yamaha_yzf_r6_1.jpg", "yamaha_yzf_r6_2.jpg", "yamaha_yzf_r6_3.jpg"], fuelType: "Gasoline", description: "A high-performance supersport motorcycle with cutting-edge technology."),
    Bike(make: "Suzuki", model: "GSX-R750", year: 2020, pricePerDay: 55.0, engineCapacity: 750, images: ["suzuki_gsx_r750_1.jpg", "suzuki_gsx_r750_2.jpg", "suzuki_gsx_r750_3.jpg"], fuelType: "Gasoline", description: "An iconic sportbike known for its balance of power and agility."),
    Bike(make: "BMW", model: "S1000RR", year: 2021, pricePerDay: 60.0, engineCapacity: 1000, images: ["bmw_s1000rr_1.jpg", "bmw_s1000rr_2.jpg", "bmw_s1000rr_3.jpg"], fuelType: "Gasoline", description: "A high-performance superbike with advanced electronics and race-inspired design."),
    Bike(make: "Ducati", model: "Panigale V2", year: 2020, pricePerDay: 65.0, engineCapacity: 955, images: ["ducati_panigale_v2_1.jpg", "ducati_panigale_v2_2.jpg", "ducati_panigale_v2_3.jpg"], fuelType: "Gasoline", description: "An exquisite Italian sportbike with breathtaking performance and exquisite craftsmanship."),
    Bike(make: "Triumph", model: "Street Triple RS", year: 2021, pricePerDay: 55.0, engineCapacity: 765, images: ["triumph_street_triple_rs_1.jpg", "triumph_street_triple_rs_2.jpg", "triumph_street_triple_rs_3.jpg"], fuelType: "Gasoline", description: "A versatile naked sportbike with exhilarating performance and agile handling."),
    Bike(make: "Harley-Davidson", model: "Iron 883", year: 2019, pricePerDay: 70.0, engineCapacity: 883, images: ["harley_iron_883_1.jpg", "harley_iron_883_2.jpg", "harley_iron_883_3.jpg"], fuelType: "Gasoline", description: "A classic cruiser motorcycle with a timeless design and distinctive Harley-Davidson rumble."),
    Bike(make: "KTM", model: "Duke 390", year: 2020, pricePerDay: 45.0, engineCapacity: 390, images: ["ktm_duke_390_1.jpg", "ktm_duke_390_2.jpg", "ktm_duke_390_3.jpg"], fuelType: "Gasoline", description: "A nimble and agile naked bike with sporty handling and a powerful engine."),
    Bike(make: "Aprilia", model: "Tuono V4 1100 Factory", year: 2021, pricePerDay: 75.0, engineCapacity: 1077, images: ["aprilia_tuono_v4_1100_factory_1.jpg", "aprilia_tuono_v4_1100_factory_2.jpg", "aprilia_tuono_v4_1100_factory_3.jpg"], fuelType: "Gasoline", description: "An exhilarating naked sportbike with race-derived performance and advanced electronics."),
    Bike(make: "MV Agusta", model: "F3 800", year: 2020, pricePerDay: 70.0, engineCapacity: 798, images: ["mv_agusta_f3_800_1.jpg", "mv_agusta_f3_800_2.jpg", "mv_agusta_f3_800_3.jpg"], fuelType: "Gasoline", description: "An Italian supersport motorcycle with stunning design and exceptional performance."),
    Bike(make: "Indian", model: "FTR 1200", year: 2019, pricePerDay: 65.0, engineCapacity: 1203, images: ["indian_ftr_1200_1.jpg", "indian_ftr_1200_2.jpg", "indian_ftr_1200_3.jpg"], fuelType: "Gasoline", description: "A powerful and versatile American flat tracker with modern performance and retro styling."),
    Bike(make: "Royal Enfield", model: "Interceptor 650", year: 2020, pricePerDay: 40.0, engineCapacity: 648, images: ["royal_enfield_interceptor_650_1.jpg", "royal_enfield_interceptor_650_2.jpg", "royal_enfield_interceptor_650_3.jpg"], fuelType: "Gasoline", description: "A classic British-inspired motorcycle with a smooth parallel-twin engine and timeless design."),
    Bike(make: "Moto Guzzi", model: "V85 TT", year: 2021, pricePerDay: 60.0, engineCapacity: 853, images: ["moto_guzzi_v85_tt_1.jpg", "moto_guzzi_v85_tt_2.jpg", "moto_guzzi_v85_tt_3.jpg"], fuelType: "Gasoline", description: "A versatile adventure motorcycle with retro styling and modern features."),
    Bike(make: "Zero", model: "SR/F", year: 2020, pricePerDay: 80.0, engineCapacity: 0, images: ["zero_sr_f_1.jpg", "zero_sr_f_2.jpg", "zero_sr_f_3.jpg"], fuelType: "Electric", description: "An electric streetfighter motorcycle with impressive torque and advanced technology."),
    Bike(make: "Husqvarna", model: "Svartpilen 401", year: 2021, pricePerDay: 50.0, engineCapacity: 373, images: ["husqvarna_svartpilen_401_1.jpg", "husqvarna_svartpilen_401_2.jpg", "husqvarna_svartpilen_401_3.jpg"], fuelType: "Gasoline", description: "A stylish and agile urban motorcycle with a unique design and lightweight chassis."),
    Bike(make: "Benelli", model: "Leoncino 500", year: 2020, pricePerDay: 45.0, engineCapacity: 500, images: ["benelli_leoncino_500_1.jpg", "benelli_leoncino_500_2.jpg", "benelli_leoncino_500_3.jpg"], fuelType: "Gasoline", description: "A modern and versatile scrambler motorcycle with classic Italian styling and a responsive engine."),
    Bike(make: "Ducati", model: "Scrambler Icon", year: 2019, pricePerDay: 55.0, engineCapacity: 803, images: ["ducati_scrambler_icon_1.jpg", "ducati_scrambler_icon_2.jpg", "ducati_scrambler_icon_3.jpg"], fuelType: "Gasoline", description: "An iconic scrambler motorcycle with a retro design and easy-going character."),
    Bike(make: "Harley-Davidson", model: "Street Glide", year: 2021, pricePerDay: 75.0, engineCapacity: 1868, images: ["harley_street_glide_1.jpg", "harley_street_glide_2.jpg", "harley_street_glide_3.jpg"], fuelType: "Gasoline", description: "A powerful touring motorcycle with comfortable ergonomics and long-distance capability."),
    Bike(make: "KTM", model: "Adventure 390", year: 2020, pricePerDay: 60.0, engineCapacity: 373, images: ["ktm_adventure_390_1.jpg", "ktm_adventure_390_2.jpg", "ktm_adventure_390_3.jpg"], fuelType: "Gasoline", description: "A lightweight adventure bike with off-road capability and versatile performance."),
]


