//
//  RootCollectionViewCell.swift
//  WheelsOnHire
//
//  Created by Varun Rachakatla on 11/04/24.
//

import UIKit

class RootCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageViewOL: UIImageView!
    
    func assignItem(with i:Vehicle){
        imageViewOL.image = i.image
    }
}
