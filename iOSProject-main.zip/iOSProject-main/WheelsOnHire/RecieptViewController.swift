//
//  RecieptViewController.swift
//  WheelsOnHire
//
//  Created by Sai Krishna Koduri on 4/22/24.
//

import UIKit

class ReceiptViewController: UIViewController {

    @IBOutlet weak var receiptNumberLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var licenseLabel: UILabel!
    @IBOutlet weak var carNameLabel: UILabel!
    @IBOutlet weak var numberOfDaysLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!


    
    var receiptNumber: String = ""
    var name: String = ""
    var licenseNumber: String = ""
    var carName: String = ""
    var numberOfDays: Int = 0
    var cost: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set receipt details
        receiptNumberLabel.text = "Receipt Number: \(receiptNumber)"
        nameLabel.text = "Name: \(name)"
        licenseLabel.text = "License Number: \(licenseNumber)"
        carNameLabel.text = "Car: \(carName)"
        numberOfDaysLabel.text = "Number of Days: \(numberOfDays)"
        costLabel.text = String(format: "Total Cost: $%.2f", cost)
    
    }
}
