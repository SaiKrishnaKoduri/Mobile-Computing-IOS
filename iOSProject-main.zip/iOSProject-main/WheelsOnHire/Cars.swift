//
//  Cars.swift
//  WheelsOnHire
//
//  Created by Sai Krishna Koduri on 4/22/24.
//

import Foundation
import UIKit

struct Car {
    let make: String
    let model: String
    let year: Int
    let pricePerDay: Double
    let availableColors: [String]
    let images: [String]
    let fuelType: String
    let transmissionType: String
    let passengerCapacity: Int
    let description: String
    
    // Additional properties and methods can be added as needed
    
    var formattedPrice: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "en_US") // Change locale as needed
        return formatter.string(from: NSNumber(value: pricePerDay)) ?? "$0.00"
    }
    
}
let cars: [Car] = [
    Car(make: "Toyota", model: "Camry", year: 2020, pricePerDay: 50.0, availableColors: ["White", "Black", "Silver"], images: ["toyota_camry_1.jpg", "toyota_camry_2.jpg", "toyota_camry_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A reliable midsize sedan with great fuel efficiency."),
    Car(make: "Honda", model: "Accord", year: 2019, pricePerDay: 55.0, availableColors: ["Red", "Blue", "Gray"], images: ["honda_accord_1.jpg", "honda_accord_2.jpg", "honda_accord_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A comfortable and stylish sedan with advanced safety features."),
    Car(make: "Ford", model: "Explorer", year: 2021, pricePerDay: 70.0, availableColors: ["Black", "White", "Blue"], images: ["ford_explorer_1.jpg", "ford_explorer_2.jpg", "ford_explorer_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 7, description: "A spacious SUV with three rows of seating, perfect for family trips."),
    Car(make: "Chevrolet", model: "Camaro", year: 2018, pricePerDay: 80.0, availableColors: ["Red", "Black", "Yellow"], images: ["chevrolet_camaro_1.jpg", "chevrolet_camaro_2.jpg", "chevrolet_camaro_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 4, description: "An iconic sports car known for its powerful performance and stylish design."),
    Car(make: "Nissan", model: "Altima", year: 2019, pricePerDay: 60.0, availableColors: ["Silver", "Blue", "Gray"], images: ["nissan_altima_1.jpg", "nissan_altima_2.jpg", "nissan_altima_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A reliable and fuel-efficient sedan with modern features."),
    Car(make: "BMW", model: "X5", year: 2020, pricePerDay: 100.0, availableColors: ["Black", "White", "Gray"], images: ["bmw_x5_1.jpg", "bmw_x5_2.jpg", "bmw_x5_3.jpg"], fuelType: "Diesel", transmissionType: "Automatic", passengerCapacity: 5, description: "A luxurious SUV with a spacious interior and advanced technology."),
    Car(make: "Tesla", model: "Model 3", year: 2021, pricePerDay: 120.0, availableColors: ["Red", "Blue", "White"], images: ["tesla_model_3_1.jpg", "tesla_model_3_2.jpg", "tesla_model_3_3.jpg"], fuelType: "Electric", transmissionType: "Automatic", passengerCapacity: 5, description: "An all-electric sedan with impressive acceleration and cutting-edge features."),
    Car(make: "Audi", model: "A4", year: 2020, pricePerDay: 90.0, availableColors: ["Black", "White", "Silver"], images: ["audi_a4_1.jpg", "audi_a4_2.jpg", "audi_a4_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A sophisticated and sporty sedan with a comfortable ride and upscale interior."),
    Car(make: "Mercedes-Benz", model: "C-Class", year: 2019, pricePerDay: 95.0, availableColors: ["Silver", "Black", "Blue"], images: ["mercedes_c_class_1.jpg", "mercedes_c_class_2.jpg", "mercedes_c_class_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A luxurious compact sedan known for its refined cabin and smooth ride."),
    Car(make: "Volkswagen", model: "Jetta", year: 2020, pricePerDay: 55.0, availableColors: ["Blue", "Black", "Gray"], images: ["volkswagen_jetta_1.jpg", "volkswagen_jetta_2.jpg", "volkswagen_jetta_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A comfortable and fuel-efficient sedan with a spacious interior."),
    Car(make: "Subaru", model: "Outback", year: 2021, pricePerDay: 65.0, availableColors: ["White", "Gray", "Green"], images: ["subaru_outback_1.jpg", "subaru_outback_2.jpg", "subaru_outback_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A versatile and capable crossover with standard all-wheel drive and a comfortable ride."),
    Car(make: "Jeep", model: "Wrangler", year: 2020, pricePerDay: 85.0, availableColors: ["Black", "White", "Gray"], images: ["jeep_wrangler_1.jpg", "jeep_wrangler_2.jpg", "jeep_wrangler_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 4, description: "An iconic off-road SUV with rugged styling and excellent off-road capabilities."),
    Car(make: "Hyundai", model: "Elantra", year: 2019, pricePerDay: 50.0, availableColors: ["White", "Black", "Silver"], images: ["hyundai_elantra_1.jpg", "hyundai_elantra_2.jpg", "hyundai_elantra_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A compact sedan with good fuel economy and a comfortable ride."),
    Car(make: "Kia", model: "Sportage", year: 2020, pricePerDay: 60.0, availableColors: ["Red", "Blue", "Black"], images: ["kia_sportage_1.jpg", "kia_sportage_2.jpg", "kia_sportage_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A compact SUV with a spacious interior and user-friendly features."),
    Car(make: "Lexus", model: "RX", year: 2021, pricePerDay: 110.0, availableColors: ["Black", "White", "Gray"], images: ["lexus_rx_1.jpg", "lexus_rx_2.jpg", "lexus_rx_3.jpg"], fuelType: "Hybrid", transmissionType: "Automatic", passengerCapacity: 5, description: "A luxury crossover with a refined interior and a smooth ride."),
    Car(make: "Mazda", model: "CX-5", year: 2020, pricePerDay: 70.0, availableColors: ["Blue", "Red", "Gray"], images: ["mazda_cx5_1.jpg", "mazda_cx5_2.jpg", "mazda_cx5_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A stylish and fun-to-drive SUV with agile handling and a comfortable cabin."),
    Car(make: "Infiniti", model: "Q50", year: 2019, pricePerDay: 85.0, availableColors: ["Black", "White", "Silver"], images: ["infiniti_q50_1.jpg", "infiniti_q50_2.jpg", "infiniti_q50_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A luxury sedan with a potent engine and a well-appointed interior."),
    Car(make: "Volvo", model: "XC60", year: 2020, pricePerDay: 95.0, availableColors: ["White", "Black", "Silver"], images: ["volvo_xc60_1.jpg", "volvo_xc60_2.jpg", "volvo_xc60_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A premium compact SUV with advanced safety features and a comfortable ride."),
    Car(make: "Buick", model: "Encore", year: 2021, pricePerDay: 75.0, availableColors: ["Red", "Blue", "White"], images: ["buick_encore_1.jpg", "buick_encore_2.jpg", "buick_encore_3.jpg"], fuelType: "Gasoline", transmissionType: "Automatic", passengerCapacity: 5, description: "A compact SUV with a refined cabin and a smooth ride."),
]




