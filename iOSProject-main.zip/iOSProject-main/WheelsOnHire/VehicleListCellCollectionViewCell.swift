//
//  VehicleListCellCollectionViewCell.swift
//  WheelsOnHire
//
//  Created by Sai Krishna Koduri on 4/22/24.
//

import UIKit

class VehicleListCellCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageViewOL: UIImageView!
    
//    func assignItem(with i: [String], at indexPath: IndexPath){
//        print(indexPath)
//        imageViewOL.image = UIImage(named: i[indexPath[1]])
//            
//        }
    
    
    
    
    func assignItem(with image: [String], at indexPath: IndexPath) {
            // Apply crossfade transition animation when loading images
            UIView.transition(with: self.imageViewOL,
                              duration: 0.3,
                              options: .transitionCrossDissolve,
                              animations: {
                                  self.imageViewOL.image = UIImage(named: image[indexPath[1]])
                              },
                              completion: nil)
        // Rotate animation
                let rotationAngle: CGFloat = CGFloat(Double.pi / 8) // Rotate by 22.5 degrees
                self.imageViewOL.transform = CGAffineTransform(rotationAngle: -rotationAngle)
                UIView.animate(withDuration: 0.5) {
                    self.imageViewOL.transform = .identity // Reset the transform to its original state
                }
                
                // Scale animation
                self.imageViewOL.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
                UIView.animate(withDuration: 0.5, delay: 0.2, options: .curveEaseInOut) {
                    self.imageViewOL.transform = .identity // Reset the transform to its original state
                }
                
                // Bounce animation
                self.imageViewOL.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
                UIView.animate(withDuration: 0.5, delay: 0.4, usingSpringWithDamping: 0.6, initialSpringVelocity: 0.5, options: .curveEaseInOut) {
                    self.imageViewOL.transform = .identity // Reset the transform to its original state
                }
                
                // You can add more animations as desired
        }
    
    }

