import UIKit

class RootViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return vehicles.count
    }
    
    var selected = ""
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var titleLabel: UILabel! // Outlet for title label
    @IBOutlet weak var descriptionLabel: UITextView! // Outlet for description label
   
    override func viewDidLoad() {
            super.viewDidLoad()
            
            // Set up collection view
            collectionView.dataSource = self
            collectionView.delegate = self
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "viewCell", for: indexPath) as! RootCollectionViewCell
            
            let vehicle = vehicles[indexPath.row]
            
            cell.assignItem(with: vehicle)
            
            return cell
        }
        
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            assignItemDetails(index: indexPath)
            let vehicle = vehicles[indexPath.row]

            selected = vehicle.title
        }
        
        func assignItemDetails(index: IndexPath) {
            let vehicle = vehicles[index.item]
            
            titleLabel.text = vehicle.title
            descriptionLabel.text = vehicle.description
            
        }
    
    @IBAction func bookVehicleBtn(_ sender: Any) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "listSegue"{
            let destination = segue.destination as! VehicleListViewController
            
            destination.selected = selected
        
        }
    }
    
}
