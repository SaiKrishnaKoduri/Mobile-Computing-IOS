//
//  ViewController.swift
//  VowelTester
//
//  Created by Koduri,Sai Krishna on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func checkButtonClicked(_ sender: Any) {
        //Read the entered text and assign to a var.
        var input = inputOL.text!.lowercased()
        //or var input = inputOL.text!.uppercased()
        //Check for vowels using if.
        if(input.contains("a") || input.contains("e") || input.contains("i") || input.contains("o") || input.contains("u")){
            //Print the message.
            print("\(input) contains vowels ")
            //Assign the output to output label
            outputOL.text = "\(input) contains vowels "
        }
        else{
            //Print the message.
            print("\(input) does not contain vowels ")
            outputOL.text = "\(input) does not contain vowels "
        }
        
    }
    
}

