//
//  ViewController.swift
//  TemperatureCheck
//
//  Created by Koduri,Sai Krishna on 1/25/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func checkWeather(_ sender: Any) {
        var temp = Int(inputOL.text!) ?? 0
        if(temp >= 60){
            outputOL.text = "It's Hot Outside"
        }
        else{
            outputOL.text = "It's Cold outside"
        }
    }
}

